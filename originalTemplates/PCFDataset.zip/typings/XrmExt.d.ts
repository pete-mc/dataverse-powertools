declare namespace Xrm {
  namespace Navigation {
    interface PageInputEntityRecordExt extends PageInputEntityRecord {
      formType: number;
    }
  }
}
