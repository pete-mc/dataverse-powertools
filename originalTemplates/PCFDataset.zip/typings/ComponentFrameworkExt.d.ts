declare namespace ComponentFramework {
  interface EntityReferenceExt extends ComponentFramework.EntityReference {
    logicalName: string;
  }
}
