# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
1.	Download and install Microsoft Power Platform CLI. https://aka.ms/PowerAppsCLI
2.	Powershell: pac install latest
3.	Run run-once.ps1
