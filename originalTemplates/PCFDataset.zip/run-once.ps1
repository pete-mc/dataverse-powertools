$ControlName = Read-Host "Enter the name of the new control"
$Namespace = Read-Host "Enter the desired namespace"
$DatasetItem = Read-Host "Enter the name of the primary dataset item"
$pubprefix = read-host "Enter the desired Publisher Prefix" 
$pubprefix | Out-File ./publisherprefix.txt

Move-Item .\components\CONTROLNAME.tsx ".\components\$ControlName.tsx" -Force
Move-Item .\components\CONTROLNAMEAPP.tsx (".\components\$ControlName"+"App.tsx") -Force
Move-Item .\viewmodels\DATASETITEM.ts ".\viewmodels\$DatasetItem.ts" -Force

$configFiles = Get-ChildItem . -Include  ('*.xml', '*.json', '*.js', '*.ts', '*.tsx')  -rec
foreach ($file in $configFiles)
{
    (Get-Content $file.PSPath) |
    Foreach-Object { ((($_ -replace "DATASETITEM", $DatasetItem) -replace "CONTROLNAME", $ControlName) -replace "NAMESPACENAME", $Namespace) -replace "CONTROLNAMEAPP", ($ControlName + "App") } |
    Set-Content $file.PSPath
}


pac pcf init --namespace $Namespace --name $ControlName --template dataset --run-npm-install false

Move-Item .\css .\$ControlName\css
Move-Item .\viewmodels .\$ControlName\viewmodels
Move-Item .\components .\$ControlName\components
Move-Item .\typings .\$ControlName\typings
Move-Item .\index.ts .\$ControlName\ -Force
Move-Item .\ControlManifest.Input.xml .\$ControlName\ -Force
Move-Item .\.eslintrc.json2 .\.eslintrc.json -Force

npm install
npm run refreshTypes
npm install -D @types/jest @types/react-beautiful-dnd @types/xrm eslint-config-prettier eslint-plugin-prettier eslint-plugin-react jest prettier ts-jest uuid jest-junit
npm install @uifabric/icons @fluentui/react interactjs mobx mobx-react moment pcf-react react react-dom 
npm install pcf-scripts pcf-start jest typescript -g

New-Item -path .\solution -ItemType Directory -Force
Set-Location .\solution\
pac solution init -pn $pubprefix -pp $pubprefix
pac solution add-reference -p ..
Set-Location ..

Remove-Item .\run-once.ps1 -Force