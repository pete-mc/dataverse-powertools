import * as React from "react";
import { ServiceProvider } from "pcf-react";
import { CONTROLNAMEVM } from "../viewmodels/CONTROLNAMEVM";
import { ServiceProviderContext } from "./context";
import { Stack } from "@fluentui/react";
import { TextInput } from "./pcf-fluent-ui/TextInput";
import { observer } from "mobx-react";
import { DialogService } from "../viewmodels/DialogService";
export interface CONTROLNAMEControlProps {
  controlWidth?: number;
  controlHeight?: number;
  serviceProvider: ServiceProvider;
}
export interface CONTROLNAMEControlState {
  hasError: boolean;
}

export class CONTROLNAMEControl extends React.Component<CONTROLNAMEControlProps, CONTROLNAMEControlState> {
  vm: CONTROLNAMEVM;
  dialogService: DialogService;
  constructor(props: CONTROLNAMEControlProps) {
    super(props);
    this.vm = props.serviceProvider.get<CONTROLNAMEVM>("ViewModel");
    this.dialogService = props.serviceProvider.get<DialogService>("DialogService");
    this.state = {
      hasError: false,
    };
  }

  static getDerivedStateFromError(error: any): CONTROLNAMEControlState {
    // Update state so the next render will show the fallback UI.
    return { hasError: true };
  }

  render(): JSX.Element {
    const { textField, onTextFieldChanged } = this.vm;
    return this.state.hasError ? (
      <>Error</>
    ) : (
      <ServiceProviderContext.Provider value={this.props.serviceProvider}>
        <Stack wrap horizontal tokens={{ maxWidth: 400 }}>
          <Stack.Item grow>
            <TextInput value={textField} onChange={onTextFieldChanged}></TextInput>
          </Stack.Item>
        </Stack>
      </ServiceProviderContext.Provider>
    );
  }
}

observer(CONTROLNAMEControl);
