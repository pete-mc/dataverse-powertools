import { ServiceProvider, ControlContextService, ParametersChangedEventArgs } from "pcf-react";
import { IInputs } from "../generated/ManifestTypes";
import { makeObservable, observable, action } from "mobx";
import { DialogService } from "./DialogService";

export class CONTROLNAMEVM {
  serviceProvider: ServiceProvider;
  controlContext: ControlContextService;
  optionSetFieldOptions: ComponentFramework.PropertyHelper.OptionMetadata[] | undefined;
  textField: string | null = null;
  optionSetField: number | null = null;
  optionSetFieldRequired: boolean;
  isPopupVisible = false;
  isFullScreen = false;

  constructor(serviceProvider: ServiceProvider) {
    makeObservable(this, {
      textField: observable,
      optionSetField: observable,
      onLoad: action.bound,
      onTextFieldChanged: action.bound,
      onInParametersChanged: action.bound,
      isPopupVisible: observable,
      onShowPopup: action.bound,
      onDismissPopup: action.bound,
      isFullScreen: observable,
      onFullScreenChanged: action.bound,
      onToggleFullScreen: action.bound,
    })
    this.serviceProvider = serviceProvider;
    this.controlContext = serviceProvider.get<ControlContextService>(ControlContextService.serviceProviderName);
    this.controlContext.onLoadEvent.subscribe(this.onLoad);
    this.controlContext.onParametersChangedEvent.subscribe(this.onInParametersChanged);
  }
  onLoad(): void {
    this.controlContext.onFullScreenModeChangedEvent.subscribe(this.onFullScreenChanged);
    this.optionSetFieldOptions = this.controlContext.getParameters<IInputs>().optionSetField.attributes?.Options;
    this.optionSetFieldRequired = this.controlContext.getParameters<IInputs>().optionSetField.attributes?.RequiredLevel == 2;
  }
  onInParametersChanged(context: ControlContextService, args: ParametersChangedEventArgs): void {
    for (const param of args.updated) {
      switch (param) {
        case "textField":
          this.textField = args.values[param] as string | null;
          break;
        case "optionSetField":
          this.optionSetField = args.values[param] as number | null;
      }
    }
  }

  onTextFieldChanged(value: string | null): void {
    this.textField = value;
    this.controlContext.setParameters({
      textField: value,
    });
  }

  onShowPopup(): void {
    this.isPopupVisible = true;
  }
  onDismissPopup(): void {
    this.isPopupVisible = false;
  }
  onToggleFullScreen(): void {
    this.isPopupVisible = false;
    this.isFullScreen = !this.isFullScreen;
    this.controlContext.fullScreen(this.isFullScreen);
  }
  onFullScreenChanged(context: ControlContextService, fullscreen: boolean): void {
    this.isFullScreen = fullscreen;
  }
}

