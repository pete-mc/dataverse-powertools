/* eslint-disable @typescript-eslint/class-name-casing */
import { StandardControlReact } from "pcf-react";
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { CONTROLNAMEControl } from "./components/CONTROLNAMEControl";
import * as React from "react";
import * as ReactDOM from "react-dom";
import { CONTROLNAMEVM } from "./viewmodels/CONTROLNAMEVM";
import { DialogService } from "./viewmodels/DialogService";

export class CONTROLNAME extends StandardControlReact<IInputs, IOutputs> {
  constructor() {
    super();
    this.renderOnParametersChanged = false;
    this.initServiceProvider = (serviceProvider): void => {
      serviceProvider.register("ViewModel", new CONTROLNAMEVM(serviceProvider));
      serviceProvider.register("DialogService", new DialogService());
    };
    this.reactCreateElement = (container, width, height, serviceProvider): void => {
      ReactDOM.render(
        React.createElement(CONTROLNAMEControl, {
          serviceProvider: serviceProvider,
          controlWidth: width,
          controlHeight: height,
        }),
        container,
      );
    };
  }
}
