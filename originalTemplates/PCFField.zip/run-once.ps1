$ControlName = Read-Host "Enter the name of the new control"
$Namespace = Read-Host "Enter the desired namespcae"
$pubprefix = read-host "Enter the desired Publisher Prefix" 
$pubprefix | Out-File ./publisherprefix.txt

Move-Item .\components\CONTROLNAMEControl.tsx (".\components\$ControlName"+"Control.tsx") -Force
Move-Item .\viewmodels\CONTROLNAMEVM.ts (".\viewmodels\$ControlName" +"VM.ts") -Force

$configFiles = Get-ChildItem . -Include  ('*.xml', '*.json', '*.js', '*.ts', '*.tsx', '*.yml')  -rec
foreach ($file in $configFiles)
{
    (Get-Content $file.PSPath) |
    Foreach-Object { (($_ -replace "CONTROLNAME", $ControlName) -replace "NAMESPACENAME", $Namespace) } |
    Set-Content $file.PSPath
}


pac pcf init --namespace $Namespace --name $ControlName --template field --run-npm-install false

Move-Item .\viewmodels .\$ControlName\viewmodels
Move-Item .\components .\$ControlName\components
Move-Item .\index.ts .\$ControlName\ -Force
Move-Item .\ControlManifest.Input.xml .\$ControlName\ -Force
Move-Item .\.eslintrc.json2 .\.eslintrc.json -Force

npm install
npm run refreshTypes
npm install -D @types/jest @types/xrm eslint-config-prettier eslint-plugin-prettier eslint-plugin-react jest prettier ts-jest uuid jest-junit
npm install @uifabric/icons @fluentui/react interactjs mobx mobx-react moment pcf-react react react-dom 
npm install pcf-scripts pcf-start jest typescript -g

New-Item -path .\solution -ItemType Directory -Force
Set-Location .\solution\
pac solution init -pn $pubprefix -pp $pubprefix
pac solution add-reference -p ..
Set-Location ..

Remove-Item .\run-once.ps1 -Force