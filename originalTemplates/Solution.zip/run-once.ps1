$SolutionName = Read-Host "Enter the solution logical name"
$OrgURL = Read-Host "Org URL"
$AppId = Read-Host "Application ID"
$Secret = Read-Host "Client Secret"

#restore
dotnet new tool-manifest
dotnet tool install paket
dotnet tool restore
dotnet paket init
dotnet paket install

# create connectionstring
('AuthType=ClientSecret;Url='+ $OrgURL +';ClientId='+ $AppId +';ClientSecret='+ $Secret +';LoginPrompt=Never') | Out-File ./connectionstring.txt

# Change solutionname
$configFiles = Get-ChildItem . -Include  ('*.cs', '*.json', '*.yml', '*.ps1') -Exclude 'run-once.ps1' -rec
foreach ($file in $configFiles)
{
    (Get-Content $file.PSPath) |
    Foreach-Object { $_ -replace "SOLUTIONNAME", $SolutionName } |
    Set-Content $file.PSPath
}

# Clean up
Remove-Item .\run-once.ps1 -Force