$conn = Get-CrmConnection -ConnectionString $env:CRMCONNECTIONSTRING -Verbose

$solutions = Get-CrmRecords -conn $conn -EntityLogicalName solution -FilterAttribute uniquename -FilterOperator eq -FilterValue SOLUTIONNAME -Fields version,friendlyname,uniquename,description 

$solutions.CrmRecords|foreach{
  $_.version = $env:VERSIONNO
  Set-CrmRecord -conn $conn -CrmRecord $_
}
