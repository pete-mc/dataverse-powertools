dotnet restore
dotnet new tool-manifest
dotnet tool install paket
dotnet tool restore; dotnet paket init
dotnet paket install
& ./packages/spkl/tools/spkl.exe unpack ./spkl.json $env:CRMCONNECTIONSTRING