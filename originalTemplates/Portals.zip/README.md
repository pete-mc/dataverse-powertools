# Instruction
This repo contains all portal related source code. <br/>

## Source code
<table>
 <thead>
    <tr>
    <th>Location</th>
    <th>Description</th>
    </tr>
 </thead>
 <tbody>
    <tr><td>/build</td><td>this contains related scripts run during build</td></tr>
    <tr><td>/portalpublish</td><td>contains copy of the portal obtained using PowerApps Portal CLI VS Extensions </td></tr>
    <tr><td>/scripts</td><td>contains Typescript code </td></tr>
    <tr><td>/scripts/compiledjs</td><td>the compiled javascript of all the typescript in this folder</td></tr>
    <tr><td>/styles</td><td>SASS preprocessors source code for css</td></tr>    
 </tbody>
</table>

## Pre-requisite
<p>Install <a href="https://marketplace.visualstudio.com/items?itemName=microsoft-IsvExpTools.powerplatform-vscode" target="_blank">Power Platform Tools extensions for VS Code</a></p>
<p>Install Type script for visual studio code compiler</p>

```
npm install -g typescript
```
<p>Install SCSS for visual studio code transpiler</p>

```
npm install -g sass less
```
### Portals
<p>If this is your first time, you might want to connect to power platform portal, do it by following the steps below. For screenshot and step by step, see this tutorial <a href="https://aylwinwong.wordpress.com/2021/05/29/managing-powerportals-code-with-vs-code-extension/" target="_blank">Managing PowerPortals code with VS Code Extension</a></p>

#### 1. Connect to Portal authentication
```
pac auth create --name portal-dev --url https://crm-dev.crm6.dynamics.com/
```

<p>Replace portal-dev with the name you want to call your portal, and the url with your CRM backend URL</p>

#### 2. List the portal and get the Website Id
```
pac paportal list
```

<p>From the list above, copy the ID of the website, and then you will need to use it for the next command</p>

#### 3. Download codes
```
pac paportal download --path ".\portalpublish\portal-dev\" --websiteId <Website-Guid>
```

<p>Replace the portal-dev folder on the path with the name that match the portal name.</p>
<p>The above command will download and overwrite all files in the folder. If you are having issue due unable to overwrite, you may delete the file under ransw-dev-pertal first and then continue</p>

## How to build
<p>Press Ctrl+Shift+B to build. This will do the following</p>
<ol>
<li>Compiles all the typescript in script folder into JS and put it in /scripts/compiledjs folder</li>
<li>Compiles all scss into css and put it in /styles/scss folder</li>
<li>Copy all the js and css file compiled above into the /portalpublish/ransw-dev-portal/webfiles</li>
</ol>
<p>The next thing you have to do is to publish it to Portal</p>

## Publish to Portal
<p>To publish your changes to portal:</p>

### 1. Update \build\portalpublish.cmd
<p>Open file \build\portalpublish.cmd and then update the first line below. Update the portal-dev with the name of your website</p>

```
SET PORTALRELEASEPATH=.\portalpublish\portal-dev\web-files
```

### 2. Upload to PowerApps Portal
<p>Run the below command on terminal. Update the path accordingly</p>

```
pac paportal upload --path ".\portalpublish\portal-dev\"
```