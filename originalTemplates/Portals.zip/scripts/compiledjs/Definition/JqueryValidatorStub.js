var Validator = /** @class */ (function () {
    function Validator(el) {
    }
    return Validator;
}());
//# sourceMappingURL=JqueryValidatorStub.js.map