﻿class Validator {
    constructor(el: any) { }
}