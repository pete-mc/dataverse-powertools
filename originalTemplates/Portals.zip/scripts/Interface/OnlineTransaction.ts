﻿interface OnlineTransaction {
    TransactionNo: string,
    Status?: number,
    Amount?: number,
    TransactionType: string,
    TransactionId: string,
    TransactionLookup: string
}