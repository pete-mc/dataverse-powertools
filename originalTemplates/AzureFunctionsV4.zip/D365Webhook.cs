using System;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace SOLUTIONNAME
{
    public partial class DataverseWebhook
    {
        [JsonProperty("BusinessUnitId")]
        public Guid BusinessUnitId { get; set; }

        [JsonProperty("CorrelationId")]
        public Guid CorrelationId { get; set; }

        [JsonProperty("Depth")]
        public long Depth { get; set; }

        [JsonProperty("InitiatingUserId")]
        public Guid InitiatingUserId { get; set; }

        [JsonProperty("InputParameters")]
        public DataverseWebhookInputParameter[] InputParameters { get; set; }

        [JsonProperty("IsExecutingOffline")]
        public bool IsExecutingOffline { get; set; }

        [JsonProperty("IsInTransaction")]
        public bool IsInTransaction { get; set; }

        [JsonProperty("IsOfflinePlayback")]
        public bool IsOfflinePlayback { get; set; }

        [JsonProperty("IsolationMode")]
        public long IsolationMode { get; set; }

        [JsonProperty("MessageName")]
        public string MessageName { get; set; }

        [JsonProperty("Mode")]
        public long Mode { get; set; }

        [JsonProperty("OperationCreatedOn")]
        public string OperationCreatedOn { get; set; }

        [JsonProperty("OperationId")]
        public Guid OperationId { get; set; }

        [JsonProperty("OrganizationId")]
        public Guid OrganizationId { get; set; }

        [JsonProperty("OrganizationName")]
        public string OrganizationName { get; set; }

        [JsonProperty("OutputParameters")]
        public object[] OutputParameters { get; set; }

        [JsonProperty("OwningExtension")]
        public OwningExtension OwningExtension { get; set; }

        [JsonProperty("ParentContext")]
        public ParentContext ParentContext { get; set; }

        [JsonProperty("PostEntityImages")]
        public PostEntityImage[] PostEntityImages { get; set; }

        [JsonProperty("PreEntityImages")]
        public object[] PreEntityImages { get; set; }

        [JsonProperty("PrimaryEntityId")]
        public Guid PrimaryEntityId { get; set; }

        [JsonProperty("PrimaryEntityName")]
        public string PrimaryEntityName { get; set; }

        [JsonProperty("RequestId")]
        public object RequestId { get; set; }

        [JsonProperty("SecondaryEntityName")]
        public string SecondaryEntityName { get; set; }

        [JsonProperty("SharedVariables")]
        public object[] SharedVariables { get; set; }

        [JsonProperty("Stage")]
        public long Stage { get; set; }

        [JsonProperty("UserId")]
        public Guid UserId { get; set; }
    }

    public partial class DataverseWebhookInputParameter
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public InputParameterValueClass Value { get; set; }
    }

    public partial class InputParameterValueClass
    {
        [JsonProperty("__type")]
        public string Type { get; set; }

        [JsonProperty("Attributes")]
        public PurpleAttribute[] Attributes { get; set; }

        [JsonProperty("EntityState")]
        public object EntityState { get; set; }

        [JsonProperty("FormattedValues")]
        public object[] FormattedValues { get; set; }

        [JsonProperty("Id")]
        public Guid Id { get; set; }

        [JsonProperty("KeyAttributes")]
        public object[] KeyAttributes { get; set; }

        [JsonProperty("LogicalName")]
        public string LogicalName { get; set; }

        [JsonProperty("RelatedEntities")]
        public object[] RelatedEntities { get; set; }

        [JsonProperty("RowVersion")]
        public object RowVersion { get; set; }
    }

    public partial class PurpleAttribute
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public AttributeValue Value { get; set; }
    }

    public partial class OwningExtension
    {
        [JsonProperty("__type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        [JsonProperty("Id")]
        public Guid Id { get; set; }

        [JsonProperty("KeyAttributes")]
        public object[] KeyAttributes { get; set; }

        [JsonProperty("LogicalName")]
        public string LogicalName { get; set; }

        [JsonProperty("Name")]
        public object Name { get; set; }

        [JsonProperty("RowVersion")]
        public object RowVersion { get; set; }
    }

    public partial class ParentContext
    {
        [JsonProperty("BusinessUnitId")]
        public Guid BusinessUnitId { get; set; }

        [JsonProperty("CorrelationId")]
        public Guid CorrelationId { get; set; }

        [JsonProperty("Depth")]
        public long Depth { get; set; }

        [JsonProperty("InitiatingUserId")]
        public Guid InitiatingUserId { get; set; }

        [JsonProperty("InputParameters")]
        public ParentContextInputParameter[] InputParameters { get; set; }

        [JsonProperty("IsExecutingOffline")]
        public bool IsExecutingOffline { get; set; }

        [JsonProperty("IsInTransaction")]
        public bool IsInTransaction { get; set; }

        [JsonProperty("IsOfflinePlayback")]
        public bool IsOfflinePlayback { get; set; }

        [JsonProperty("IsolationMode")]
        public long IsolationMode { get; set; }

        [JsonProperty("MessageName")]
        public MessageName MessageName { get; set; }

        [JsonProperty("Mode")]
        public long Mode { get; set; }

        [JsonProperty("OperationCreatedOn")]
        public string OperationCreatedOn { get; set; }

        [JsonProperty("OperationId")]
        public Guid OperationId { get; set; }

        [JsonProperty("OrganizationId")]
        public Guid OrganizationId { get; set; }

        [JsonProperty("OrganizationName")]
        public string OrganizationName { get; set; }

        [JsonProperty("OutputParameters")]
        public object[] OutputParameters { get; set; }

        [JsonProperty("OwningExtension")]
        public OwningExtension OwningExtension { get; set; }

        [JsonProperty("ParentContext")]
        public object ParentContextParentContext { get; set; }

        [JsonProperty("PostEntityImages")]
        public object[] PostEntityImages { get; set; }

        [JsonProperty("PreEntityImages")]
        public object[] PreEntityImages { get; set; }

        [JsonProperty("PrimaryEntityId")]
        public Guid PrimaryEntityId { get; set; }

        [JsonProperty("PrimaryEntityName")]
        public string PrimaryEntityName { get; set; }

        [JsonProperty("RequestId")]
        public object RequestId { get; set; }

        [JsonProperty("SecondaryEntityName")]
        public string SecondaryEntityName { get; set; }

        [JsonProperty("SharedVariables")]
        public SharedVariable[] SharedVariables { get; set; }

        [JsonProperty("Stage")]
        public long Stage { get; set; }

        [JsonProperty("UserId")]
        public Guid UserId { get; set; }
    }

    public partial class ParentContextInputParameter
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public InputParameterValueUnion Value { get; set; }
    }

    public partial class ValueValue
    {
        [JsonProperty("__type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        [JsonProperty("Attributes")]
        public FluffyAttribute[] Attributes { get; set; }

        [JsonProperty("EntityState")]
        public object EntityState { get; set; }

        [JsonProperty("FormattedValues")]
        public object[] FormattedValues { get; set; }

        [JsonProperty("Id")]
        public Guid Id { get; set; }

        [JsonProperty("KeyAttributes")]
        public object[] KeyAttributes { get; set; }

        [JsonProperty("LogicalName")]
        public string LogicalName { get; set; }

        [JsonProperty("RelatedEntities")]
        public object[] RelatedEntities { get; set; }

        [JsonProperty("RowVersion")]
        public object RowVersion { get; set; }
    }

    public partial class FluffyAttribute
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }
    }

    public partial class SharedVariable
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public ValueElement[] Value { get; set; }
    }

    public partial class ValueElement
    {
        [JsonProperty("__type")]
        public TypeEnum Type { get; set; }

        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public MessageName Value { get; set; }
    }

    public partial class PostEntityImage
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public ValueValue Value { get; set; }
    }

    public enum MessageName { Update };

    public enum TypeEnum { KeyValuePairOfstringstringSystemCollectionsGeneric };

    public partial struct AttributeValue
    {
        public OwningExtension OwningExtension;
        public string String;

        public static implicit operator AttributeValue(OwningExtension OwningExtension) => new AttributeValue { OwningExtension = OwningExtension };
        public static implicit operator AttributeValue(string String) => new AttributeValue { String = String };
        public bool IsNull => OwningExtension == null && String == null;
    }

    public partial struct InputParameterValueUnion
    {
        public bool? Bool;
        public ValueValue ValueValue;

        public static implicit operator InputParameterValueUnion(bool Bool) => new InputParameterValueUnion { Bool = Bool };
        public static implicit operator InputParameterValueUnion(ValueValue ValueValue) => new InputParameterValueUnion { ValueValue = ValueValue };
    }

    public partial class DataverseWebhook
    {
        public static DataverseWebhook FromJson(string json) => JsonConvert.DeserializeObject<DataverseWebhook>(json, SOLUTIONNAME.Converter.Settings);
    }

    public static class Serialize
    {
        public static string ToJson(this DataverseWebhook self) => JsonConvert.SerializeObject(self, SOLUTIONNAME.Converter.Settings);
    }

    internal static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters = {
                AttributeValueConverter.Singleton,
                InputParameterValueUnionConverter.Singleton,
                MessageNameConverter.Singleton,
                TypeEnumConverter.Singleton,
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
        };
    }

    internal class AttributeValueConverter : JsonConverter
    {
        public override bool CanConvert(Type t) => t == typeof(AttributeValue) || t == typeof(AttributeValue?);

        public override object ReadJson(JsonReader reader, Type t, object existingValue, JsonSerializer serializer)
        {
            switch (reader.TokenType)
            {
                case JsonToken.Null:
                    return new AttributeValue { };
                case JsonToken.String:
                case JsonToken.Date:
                    var stringValue = serializer.Deserialize<string>(reader);
                    return new AttributeValue { String = stringValue };
                case JsonToken.StartObject:
                    var objectValue = serializer.Deserialize<OwningExtension>(reader);
                    return new AttributeValue { OwningExtension = objectValue };
            }
            throw new Exception("Cannot unmarshal type AttributeValue");
        }

        public override void WriteJson(JsonWriter writer, object untypedValue, JsonSerializer serializer)
        {
            var value = (AttributeValue)untypedValue;
            if (value.IsNull)
            {
                serializer.Serialize(writer, null);
                return;
            }
            if (value.String != null)
            {
                serializer.Serialize(writer, value.String);
                return;
            }
            if (value.OwningExtension != null)
            {
                serializer.Serialize(writer, value.OwningExtension);
                return;
            }
            throw new Exception("Cannot marshal type AttributeValue");
        }

        public static readonly AttributeValueConverter Singleton = new AttributeValueConverter();
    }

    internal class InputParameterValueUnionConverter : JsonConverter
    {
        public override bool CanConvert(Type t) => t == typeof(InputParameterValueUnion) || t == typeof(InputParameterValueUnion?);

        public override object ReadJson(JsonReader reader, Type t, object existingValue, JsonSerializer serializer)
        {
            switch (reader.TokenType)
            {
                case JsonToken.Boolean:
                    var boolValue = serializer.Deserialize<bool>(reader);
                    return new InputParameterValueUnion { Bool = boolValue };
                case JsonToken.StartObject:
                    var objectValue = serializer.Deserialize<ValueValue>(reader);
                    return new InputParameterValueUnion { ValueValue = objectValue };
            }
            throw new Exception("Cannot unmarshal type InputParameterValueUnion");
        }

        public override void WriteJson(JsonWriter writer, object untypedValue, JsonSerializer serializer)
        {
            var value = (InputParameterValueUnion)untypedValue;
            if (value.Bool != null)
            {
                serializer.Serialize(writer, value.Bool.Value);
                return;
            }
            if (value.ValueValue != null)
            {
                serializer.Serialize(writer, value.ValueValue);
                return;
            }
            throw new Exception("Cannot marshal type InputParameterValueUnion");
        }

        public static readonly InputParameterValueUnionConverter Singleton = new InputParameterValueUnionConverter();
    }

    internal class MessageNameConverter : JsonConverter
    {
        public override bool CanConvert(Type t) => t == typeof(MessageName) || t == typeof(MessageName?);

        public override object ReadJson(JsonReader reader, Type t, object existingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.Null) return null;
            var value = serializer.Deserialize<string>(reader);
            if (value == "Update")
            {
                return MessageName.Update;
            }
            throw new Exception("Cannot unmarshal type MessageName");
        }

        public override void WriteJson(JsonWriter writer, object untypedValue, JsonSerializer serializer)
        {
            if (untypedValue == null)
            {
                serializer.Serialize(writer, null);
                return;
            }
            var value = (MessageName)untypedValue;
            if (value == MessageName.Update)
            {
                serializer.Serialize(writer, "Update");
                return;
            }
            throw new Exception("Cannot marshal type MessageName");
        }

        public static readonly MessageNameConverter Singleton = new MessageNameConverter();
    }

    internal class TypeEnumConverter : JsonConverter
    {
        public override bool CanConvert(Type t) => t == typeof(TypeEnum) || t == typeof(TypeEnum?);

        public override object ReadJson(JsonReader reader, Type t, object existingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.Null) return null;
            var value = serializer.Deserialize<string>(reader);
            if (value == "KeyValuePairOfstringstring:#System.Collections.Generic")
            {
                return TypeEnum.KeyValuePairOfstringstringSystemCollectionsGeneric;
            }
            throw new Exception("Cannot unmarshal type TypeEnum");
        }

        public override void WriteJson(JsonWriter writer, object untypedValue, JsonSerializer serializer)
        {
            if (untypedValue == null)
            {
                serializer.Serialize(writer, null);
                return;
            }
            var value = (TypeEnum)untypedValue;
            if (value == TypeEnum.KeyValuePairOfstringstringSystemCollectionsGeneric)
            {
                serializer.Serialize(writer, "KeyValuePairOfstringstring:#System.Collections.Generic");
                return;
            }
            throw new Exception("Cannot marshal type TypeEnum");
        }

        public static readonly TypeEnumConverter Singleton = new TypeEnumConverter();
    }
}
