if(test-path 'host.json'){
  $OrgURL = Read-Host "Org URL";
  $AppId = Read-Host "Application ID";
  $Secret = Read-Host "Client Secret";
  $connString = ('AuthType=ClientSecret;Url='+ $OrgURL +';ClientId='+ $AppId +';ClientSecret='+ $Secret +';LoginPrompt=Never');
  
  dotnet add package Microsoft.PowerPlatform.Dataverse.Client
  dotnet restore
  dotnet new tool-manifest
  dotnet tool install paket
  dotnet tool restore
  dotnet paket init
  dotnet paket install

  $csFiles = Get-ChildItem . -Include  ('*.cs') -rec -Exclude D365Webhook.cs
  $namespace = "missing";
  
  foreach ($file in $csFiles) 
  {
      (Get-Content $file.PSPath) | Foreach-Object { 
        if($_.IndexOf("namespace") -ge 0){$namespace = $_.replace("namespace ","")}       
        $_
        if($_.Contains("using System;")){
          'using Microsoft.Xrm.Sdk;'
          'using Microsoft.PowerPlatform.Dataverse.Client;'
          'using Microsoft.Crm.Sdk.Messages;'
        } 
        if($_.Contains("log.LogInformation")){
          '            var service = new ServiceClient(Environment.GetEnvironmentVariable("CRMConnectionString"));'
          '            if (service.IsReady)'
          '            {'
          '                RetrieveVersionResponse versionResponse = (RetrieveVersionResponse)service.Execute(new RetrieveVersionRequest());'
          '                log.LogInformation("Retrieved version: " + versionResponse.Version);'
          '            }'
          '            else'
          '            {'
          '                log.LogError("Failed to connect to Dynamics 365.");'
          '                throw new Exception("Failed to connect to Dynamics 365");'
          '            }'
          ''
          '            //do stuff'
          '            // service.Create(new Entity("contact") { ["firstname"] = "John", ["lastname"] = "Doe" });'
        } 
      } | Set-Content $file.PSPath
  }  

  $jsonFiles = Get-ChildItem . -Include  ('D365Webhook.cs', '*.json') -rec  
  foreach ($file in $jsonFiles) 
  {
      (Get-Content $file.PSPath) | Foreach-Object { 
        $line = $_
        $line = $line.replace('SOLUTIONNAME', $namespace)
        $line
      } | Set-Content $file.PSPath
    }
  

  $settings = Get-Content .\local.settings.json | ConvertFrom-Json
  $settings.Values | add-member -type NoteProperty -name CRMConnectionString -Value $connString -Force
  $settings | ConvertTo-Json | Out-File .\local.settings.json -Encoding UTF8
  
  ('AuthType=ClientSecret;Url='+ $OrgURL +';ClientId='+ $AppId +';ClientSecret='+ $Secret +';LoginPrompt=Never') | Out-File ./connectionstring.txt
  Move-Item (Get-ChildItem -Recurse -File -Path CrmPluginRegistrationAttribute.cs).FullName ".\CrmPluginRegistrationAttribute.generated.cs"
  remove-item .\run-once.ps1 -force
}
else{
  Write-Host "Function has not been configured. Please use the VS Code Azure Function extenstion to configure the function." -ForegroundColor Red
}