# Getting Started
Download the following requirements:
1.	[.Net 6.0 SDK](https://dotnet.microsoft.com/en-us/download/dotnet/6.0)
2.	[Azure Functions Core Tools](https://go.microsoft.com/fwlink/?linkid=2174087)
3.	[VS Code](https://code.visualstudio.com/)
4.	[C# Plugin for VS Code](https://marketplace.visualstudio.com/items?itemName=ms-dotnettools.csharp)
5.  [Azure Functions Plugin for VS Code](https://marketplace.visualstudio.com/items?itemName=ms-azuretools.vscode-azurefunctions)

To create a function follow these steps:
1.  Create a new azure function project 
    ![](https://docs.microsoft.com/en-us/azure/azure-functions/media/functions-create-first-function-vs-code/create-new-project.png)
2.  Complete the prompts based on your needs
3.  Run run-once.ps1 to get started

# Build and Test
Visit instuctions on how to run and release functions [here](https://docs.microsoft.com/en-us/azure/azure-functions/create-first-function-vs-code-csharp?tabs=in-process#run-the-function-locally).