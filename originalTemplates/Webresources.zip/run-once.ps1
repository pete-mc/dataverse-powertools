$SolutionName = Read-Host "Enter the solution logical name (without trailing slash)"
$PublisherPrefix = Read-Host "Enter the publisher prefix (without trailing underscore)"
$OrgURL = Read-Host "Org URL"
$AppId = Read-Host "Application ID"
$Secret = Read-Host "Client Secret"

# Change solutionname
$configFiles = Get-ChildItem . -Include  ('*.cs', '*.json', '*.js')  -rec
foreach ($file in $configFiles)
{
    (Get-Content $file.PSPath) |
    Foreach-Object { $_ -replace "SOLUTIONNAME", $SolutionName } |
    Set-Content $file.PSPath
}
foreach ($file in $configFiles)
{
    (Get-Content $file.PSPath) |
    Foreach-Object { $_ -replace "PREFIX", $PublisherPrefix } |
    Set-Content $file.PSPath
}
npm i typescript moment
npm i eslint eslint-config-prettier @types/jest @typescript-eslint/eslint-plugin @typescript-eslint/parser eslint-plugin-react jest jest-cli prettier syswide-cas ts-jest ts-loader webpack webpack-cli webpack-merge xrm-mock eslint-plugin-prettier jest-junit --save-dev

dotnet new tool-manifest
dotnet tool install paket
dotnet tool restore
dotnet paket init
dotnet paket install

# create connectionstring
('AuthType=ClientSecret;Url='+ $OrgURL +';ClientId='+ $AppId +';ClientSecret='+ $Secret +';LoginPrompt=Never') | Out-File ./connectionstring.txt

# Clean up template files and script
Remove-Item .\run-once.ps1 -Force