# Getting Started
1.	Install the latest version of Chrome on your computer (Edge is not supported)
2.	Run run-once to get started
3.	Put credentials and url into the app.config
4.	run dotnet build to build
5.	run donnet test to run tests

