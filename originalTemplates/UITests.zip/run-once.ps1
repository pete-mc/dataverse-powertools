$SolutionName = Read-Host "Enter the project logical name"

dotnet new sln
dotnet new mstest -o "${SolutionName}" --target-framework-override net472
dotnet sln add ".\$SolutionName\$SolutionName.csproj"

dotnet add ".\$SolutionName\$SolutionName.csproj" package Selenium.Support
dotnet add ".\$SolutionName\$SolutionName.csproj" package Selenium.WebDriver
dotnet add ".\$SolutionName\$SolutionName.csproj" package Newtonsoft.Json
dotnet add ".\$SolutionName\$SolutionName.csproj" package System.Configuration.ConfigurationManager
dotnet add ".\$SolutionName\$SolutionName.csproj" package Selenium.WebDriver.ChromeDriver

(Get-Content ".\$SolutionName\$SolutionName.csproj") | Foreach-Object { 
  if (!$_.Contains("<Nullable>enable</Nullable>")) {$_}
  if($_.Contains("</ItemGroup>")){
  ''
  '<ItemGroup>'
  '  <Reference Include="Microsoft.Dynamics365.UIAutomation.Api">'
  '   <HintPath>..\EasyRepro\Microsoft.Dynamics365.UIAutomation.Api.dll</HintPath>'
  '  </Reference>'
  '  <Reference Include="Microsoft.Dynamics365.UIAutomation.Api.UCI">'
  '   <HintPath>..\EasyRepro\Microsoft.Dynamics365.UIAutomation.Api.UCI.dll</HintPath>'
  '  </Reference>'
  '  <Reference Include="Microsoft.Dynamics365.UIAutomation.Browser">'
  '   <HintPath>..\EasyRepro\Microsoft.Dynamics365.UIAutomation.Browser.dll</HintPath>'
  '  </Reference>'
  '</ItemGroup>'
 
  } 
} | Set-Content ".\$SolutionName\$SolutionName.csproj"

# Change namespace
$configFiles = Get-ChildItem .\TemplateFiles -Include  ('*.cs', '*.config')  -rec
foreach ($file in $configFiles)
{
    (Get-Content $file.PSPath) |
    Foreach-Object { $_ -replace "NSNAME", $SolutionName } |
    Set-Content $file.PSPath
}

Copy-Item .\TemplateFiles\* .\$SolutionName -recurse -force

Write-host "Complete - Please set test credentials in app.config as needed" -ForegroundColor Green
Remove-Item TemplateFiles -Recurse -Force
Remove-Item .\run-once.ps1 -Force