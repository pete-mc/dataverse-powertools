$SolutionName = Read-Host "Enter the solution logical name"
$OrgURL = Read-Host "Org URL"
$AppId = Read-Host "Application ID"
$Secret = Read-Host "Client Secret"

# Create SLN and Proj files and install packages
dotnet new sln
dotnet new classlib -o "$SolutionName" --target-framework-override net471
dotnet new xunit -o "${SolutionName}Tests" --target-framework-override net471
dotnet sln add "$SolutionName/$SolutionName.csproj"
dotnet sln add "${SolutionName}Tests/${SolutionName}Tests.csproj"
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" reference "$SolutionName/$SolutionName.csproj"
dotnet add "$SolutionName/$SolutionName.csproj" package spkl
dotnet add "$SolutionName/$SolutionName.csproj" package Microsoft.CrmSdk.CoreAssemblies
dotnet add "$SolutionName/$SolutionName.csproj" package Microsoft.CrmSdk.Workflow
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" package FakeXrmEasy.9
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" package Microsoft.NET.Test.Sdk
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" package xunit
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" package xunit.runner.visualstudio
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" package coverlet.collector
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" package Microsoft.CrmSdk.CoreAssemblies
dotnet add "${SolutionName}Tests/${SolutionName}Tests.csproj" package Microsoft.CrmSdk.Workflow

# Fix Class Library
$doc = New-Object System.Xml.XmlDocument
$doc.Load("$SolutionName/$SolutionName.csproj")                   
$SignAssembly = $doc.CreateElement("SignAssembly")
$SignAssembly.InnerText = "true"      
$doc.Project.PropertyGroup.AppendChild($SignAssembly)
$AssemblyOriginatorKeyFile = $doc.CreateElement("AssemblyOriginatorKeyFile")
$AssemblyOriginatorKeyFile.InnerText = "Clade.snk"      
$doc.Project.PropertyGroup.AppendChild($SignAssembly)
$doc.Project.PropertyGroup.AppendChild($AssemblyOriginatorKeyFile)
$doc.Save("$SolutionName/$SolutionName.csproj")

#copy template files
Copy-Item .\TemplateFiles\ClassLibrary\Clade.snk .\$SolutionName
Copy-Item .\TemplateFiles\ClassLibrary\Plugin.cs .\$SolutionName
Copy-Item .\TemplateFiles\Tests\Plugin.Tests.cs .\${SolutionName}Tests
Remove-Item .\${SolutionName}Tests\UnitTest1.cs
Remove-Item .\$SolutionName\Class1.cs

#restore
dotnet restore
dotnet new tool-manifest
dotnet tool install paket
dotnet tool restore
dotnet paket init
dotnet paket install

#Copy SPKL files
Copy-Item .\TemplateFiles\ClassLibrary\spkl.json ".\$SolutionName\spkl.json"
Copy-Item (Get-ChildItem -Recurse -File -Path CrmPluginRegistrationAttribute.cs).FullName ".\$SolutionName\CrmPluginRegistrationAttribute.generated.cs"
# create connectionstring
('AuthType=ClientSecret;Url='+ $OrgURL +';ClientId='+ $AppId +';ClientSecret='+ $Secret +';LoginPrompt=Never') | Out-File ./connectionstring.txt

# Change solutionname
$configFiles = Get-ChildItem . -Include  ('*.cs', '*.json', '*.yml')  -rec
foreach ($file in $configFiles)
{
    (Get-Content $file.PSPath) |
    Foreach-Object { $_ -replace "SOLUTIONNAME", $SolutionName } |
    Set-Content $file.PSPath
}

#updated to remove version issues
(get-content "${SolutionName}\${SolutionName}.csproj") -replace "<ImplicitUsings>enable</ImplicitUsings>","" | Out-File "${SolutionName}\${SolutionName}.csproj"
(get-content "${SolutionName}\${SolutionName}.csproj") -replace "<Nullable>enable</Nullable>","" | Out-File "${SolutionName}\${SolutionName}.csproj"
(get-content "${SolutionName}Tests\${SolutionName}Tests.csproj") -replace "<Nullable>enable</Nullable>","" | Out-File "${SolutionName}Tests\${SolutionName}Tests.csproj"


# Clean up template files and script
Remove-Item TemplateFiles -Recurse -Force
Remove-Item .\run-once.ps1 -Force

New-Item -Path ".\$SolutionName\" -Name "generated" -ItemType "directory"
